-- Database migration for chat system
-- Run this SQL to update your database schema

-- First, let's check if the messages table exists and create it if needed
CREATE TABLE IF NOT EXISTS messages (
  `message_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `sender_id` bigint UNSIGNED NOT NULL,
  `receiver_id` bigint UNSIGNED NOT NULL,
  `content` text NOT NULL,
  `message_type` enum('text','image','file') DEFAULT 'text',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Add missing columns to messages table if they don't exist
ALTER TABLE messages 
ADD COLUMN IF NOT EXISTS `is_read` TINYINT(1) DEFAULT 0,
ADD COLUMN IF NOT EXISTS `message_type` ENUM('text', 'image', 'file') DEFAULT 'text',
ADD COLUMN IF NOT EXISTS `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_messages_sender_receiver ON messages(sender_id, receiver_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at);
CREATE INDEX IF NOT EXISTS idx_messages_is_read ON messages(is_read);

-- Add foreign key constraints if they don't exist
ALTER TABLE messages 
ADD CONSTRAINT IF NOT EXISTS fk_messages_sender 
FOREIGN KEY (sender_id) REFERENCES users(user_id) ON DELETE CASCADE,
ADD CONSTRAINT IF NOT EXISTS fk_messages_receiver 
FOREIGN KEY (receiver_id) REFERENCES users(user_id) ON DELETE CASCADE;

-- Update existing messages to have is_read = 0
UPDATE messages SET is_read = 0 WHERE is_read IS NULL;

-- Update existing messages to have message_type = 'text'
UPDATE messages SET message_type = 'text' WHERE message_type IS NULL;

-- Remove the old 'role' column if it exists (since we don't need it)
ALTER TABLE messages DROP COLUMN IF EXISTS `role`;

-- Sample data for testing (optional) - only insert if table is empty
INSERT IGNORE INTO messages (sender_id, receiver_id, content, message_type, created_at, is_read) VALUES
(1, 8, 'Welcome to the property! Let me know if you need anything.', 'text', NOW(), 0),
(8, 1, 'Thank you! I have a question about the lease agreement.', 'text', NOW(), 0),
(1, 11, 'Please check the kitchen sink issue at Oceanview Retreat.', 'text', NOW(), 0),
(11, 1, 'Received. I will visit tomorrow morning.', 'text', NOW(), 0),
(9, 1, 'Rent payment completed for August month.', 'text', NOW(), 0),
(1, 9, 'Payment received. Thank you!', 'text', NOW(), 0),
(12, 1, 'Invoice for maintenance work sent.', 'text', NOW(), 0),
(1, 12, 'Payment will be processed within 2 business days.', 'text', NOW(), 0);

-- Verify the table structure
DESCRIBE messages;
